<?php
// Test universal asset handler
echo "<h1>Universal Asset Handler Test</h1>";

echo "<h2>Testing with current filenames:</h2>";
echo "<p><a href='assets/index-C1HYeMMR.js' target='_blank'>Current JS: index-C1HYeMMR.js</a></p>";
echo "<p><a href='assets/index-BzE54ZKj.css' target='_blank'>Current CSS: index-BzE54ZKj.css</a></p>";

echo "<h2>Testing with server filenames (from console errors):</h2>";
echo "<p><a href='assets/index-2LvNiv13.js' target='_blank'>Server JS: index-2LvNiv13.js</a></p>";
echo "<p><a href='assets/index-CmhVkJFI.css' target='_blank'>Server CSS: index-CmhVkJFI.css</a></p>";

echo "<h2>Available files in assets directory:</h2>";
$assetsDir = __DIR__ . '/assets/';
if (is_dir($assetsDir)) {
    $files = scandir($assetsDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            echo "<p><a href='assets/$file' target='_blank'>$file</a></p>";
        }
    }
} else {
    echo "<p>Assets directory not found!</p>";
}

echo "<h2>Test Results:</h2>";
echo "<p>If the links above work, the universal handler is working correctly.</p>";
echo "<p>If they show 'File not found', we need to upload the correct asset files.</p>";
?>

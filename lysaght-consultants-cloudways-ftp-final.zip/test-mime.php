<?php
// Test file to verify MIME types are working
echo "<h1>MIME Type Test</h1>";

echo "<h2>Testing JavaScript MIME Type:</h2>";
echo "<p>Click this link to test JS MIME type: <a href='assets.php?file=index-C1HYeMMR.js' target='_blank'>Test JS File</a></p>";

echo "<h2>Testing CSS MIME Type:</h2>";
echo "<p>Click this link to test CSS MIME type: <a href='assets.php?file=index-BzE54ZKj.css' target='_blank'>Test CSS File</a></p>";

echo "<h2>Direct PHP Links:</h2>";
echo "<p><a href='assets/index-C1HYeMMR.js.php' target='_blank'>Direct JS PHP</a></p>";
echo "<p><a href='assets/index-BzE54ZKj.css.php' target='_blank'>Direct CSS PHP</a></p>";

echo "<h2>Server Info:</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Server: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
?>

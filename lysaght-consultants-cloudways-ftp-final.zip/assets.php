<?php
// Universal asset handler for any filename
$requestUri = $_SERVER['REQUEST_URI'];

// Extract the filename from the request
$filename = basename($requestUri);

// Get file extension
$pathInfo = pathinfo($filename);
$extension = strtolower($pathInfo['extension'] ?? '');

// Map file extensions to MIME types
$mimeTypes = [
    'js' => 'application/javascript',
    'mjs' => 'application/javascript',
    'css' => 'text/css',
    'png' => 'image/png',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'gif' => 'image/gif',
    'svg' => 'image/svg+xml',
    'ico' => 'image/x-icon',
    'woff' => 'font/woff',
    'woff2' => 'font/woff2',
    'ttf' => 'font/ttf',
    'eot' => 'application/vnd.ms-fontobject'
];

// Set appropriate MIME type
if (isset($mimeTypes[$extension])) {
    header('Content-Type: ' . $mimeTypes[$extension]);
} else {
    header('Content-Type: application/octet-stream');
}

// Set cache headers for static assets
if (in_array($extension, ['js', 'css', 'png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'woff', 'woff2', 'ttf', 'eot'])) {
    header('Cache-Control: public, max-age=31536000');
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
}

// Look for the file in the assets directory
$assetsDir = __DIR__ . '/assets/';
$actualFile = $assetsDir . $filename;

// Check if file exists
if (file_exists($actualFile)) {
    readfile($actualFile);
} else {
    // File not found - return 404 with appropriate content type
    http_response_code(404);
    if ($extension === 'js') {
        echo '// File not found: ' . htmlspecialchars($filename);
    } elseif ($extension === 'css') {
        echo '/* File not found: ' . htmlspecialchars($filename) . ' */';
    } else {
        echo 'File not found: ' . htmlspecialchars($filename);
    }
}
?>
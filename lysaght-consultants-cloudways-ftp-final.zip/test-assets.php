<?php
// Test individual asset files
echo "<h1>Asset Test</h1>";

echo "<h2>Testing JavaScript:</h2>";
echo "<p>Direct link: <a href='index.php/assets/index-C1HYeMMR.js' target='_blank'>JS via index.php</a></p>";

echo "<h2>Testing CSS:</h2>";
echo "<p>Direct link: <a href='index.php/assets/index-BzE54ZKj.css' target='_blank'>CSS via index.php</a></p>";

echo "<h2>Testing Original Files:</h2>";
echo "<p>Original JS: <a href='assets/index-C1HYeMMR.js' target='_blank'>Original JS</a></p>";
echo "<p>Original CSS: <a href='assets/index-BzE54ZKj.css' target='_blank'>Original CSS</a></p>";

echo "<h2>File Check:</h2>";
$jsFile = __DIR__ . '/assets/index-C1HYeMMR.js';
$cssFile = __DIR__ . '/assets/index-BzE54ZKj.css';

echo "<p>JS file exists: " . (file_exists($jsFile) ? 'YES' : 'NO') . "</p>";
echo "<p>CSS file exists: " . (file_exists($cssFile) ? 'YES' : 'NO') . "</p>";

if (file_exists($jsFile)) {
    echo "<p>JS file size: " . filesize($jsFile) . " bytes</p>";
}
if (file_exists($cssFile)) {
    echo "<p>CSS file size: " . filesize($cssFile) . " bytes</p>";
}
?>
